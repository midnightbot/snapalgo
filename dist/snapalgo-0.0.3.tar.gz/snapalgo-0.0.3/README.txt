Available Algorithm
Sorting
    - Bubble Sort
    - Insertion Sort
    - Merge Sort
    - Radix Sort
